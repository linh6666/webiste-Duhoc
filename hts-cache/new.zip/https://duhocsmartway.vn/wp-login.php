<!DOCTYPE html>
	<html lang="vi">
	<head>
	<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
	<title>Đăng nhập &lsaquo; Du Học Smart Way &#8212; WordPress</title>
	<meta name='robots' content='max-image-preview:large, noindex, noarchive' />
<link rel='stylesheet' id='dashicons-css' href='https://duhocsmartway.vn/wp-includes/css/dashicons.min.css?ver=6.7.1' type='text/css' media='all' />
<link rel='stylesheet' id='buttons-css' href='https://duhocsmartway.vn/wp-includes/css/buttons.min.css?ver=6.7.1' type='text/css' media='all' />
<link rel='stylesheet' id='forms-css' href='https://duhocsmartway.vn/wp-admin/css/forms.min.css?ver=6.7.1' type='text/css' media='all' />
<link rel='stylesheet' id='l10n-css' href='https://duhocsmartway.vn/wp-admin/css/l10n.min.css?ver=6.7.1' type='text/css' media='all' />
<link rel='stylesheet' id='login-css' href='https://duhocsmartway.vn/wp-admin/css/login.min.css?ver=6.7.1' type='text/css' media='all' />
<script type="text/javascript">
(function(url){
	if(/(?:Chrome\/26\.0\.1410\.63 Safari\/537\.31|WordfenceTestMonBot)/.test(navigator.userAgent)){ return; }
	var addEvent = function(evt, handler) {
		if (window.addEventListener) {
			document.addEventListener(evt, handler, false);
		} else if (window.attachEvent) {
			document.attachEvent('on' + evt, handler);
		}
	};
	var removeEvent = function(evt, handler) {
		if (window.removeEventListener) {
			document.removeEventListener(evt, handler, false);
		} else if (window.detachEvent) {
			document.detachEvent('on' + evt, handler);
		}
	};
	var evts = 'contextmenu dblclick drag dragend dragenter dragleave dragover dragstart drop keydown keypress keyup mousedown mousemove mouseout mouseover mouseup mousewheel scroll'.split(' ');
	var logHuman = function() {
		if (window.wfLogHumanRan) { return; }
		window.wfLogHumanRan = true;
		var wfscr = document.createElement('script');
		wfscr.type = 'text/javascript';
		wfscr.async = true;
		wfscr.src = url + '&r=' + Math.random();
		(document.getElementsByTagName('head')[0]||document.getElementsByTagName('body')[0]).appendChild(wfscr);
		for (var i = 0; i < evts.length; i++) {
			removeEvent(evts[i], logHuman);
		}
	};
	for (var i = 0; i < evts.length; i++) {
		addEvent(evts[i], logHuman);
	}
})('//duhocsmartway.vn/?wordfence_lh=1&hid=5A7519BE492D3D3D494F389AA1F31F26');
</script>	<meta name='referrer' content='strict-origin-when-cross-origin' />
		<meta name="viewport" content="width=device-width, initial-scale=1.0" />
	<link rel="icon" href="https://duhocsmartway.vn/wp-content/uploads/2023/06/cropped-z4464769059915_47bc8074231d8b34b50a9fa4fc705731-32x32.jpg" sizes="32x32" />
<link rel="icon" href="https://duhocsmartway.vn/wp-content/uploads/2023/06/cropped-z4464769059915_47bc8074231d8b34b50a9fa4fc705731-192x192.jpg" sizes="192x192" />
<link rel="apple-touch-icon" href="https://duhocsmartway.vn/wp-content/uploads/2023/06/cropped-z4464769059915_47bc8074231d8b34b50a9fa4fc705731-180x180.jpg" />
<meta name="msapplication-TileImage" content="https://duhocsmartway.vn/wp-content/uploads/2023/06/cropped-z4464769059915_47bc8074231d8b34b50a9fa4fc705731-270x270.jpg" />
	</head>
	<body class="login no-js login-action-login wp-core-ui  locale-vi">
	<script type="text/javascript">
/* <![CDATA[ */
document.body.className = document.body.className.replace('no-js','js');
/* ]]> */
</script>

				<h1 class="screen-reader-text">Đăng nhập</h1>
			<div id="login">
		<h1 role="presentation" class="wp-login-logo"><a href="https://vi.wordpress.org/">Xây dựng bằng WordPress</a></h1>
	<div id="login_error" class="notice notice-error"><p>Hãy đăng nhập lại.</p></div>
		<form name="loginform" id="loginform" action="https://duhocsmartway.vn/wp-login.php" method="post">
			<p>
				<label for="user_login">Tên người dùng hoặc địa chỉ email</label>
				<input type="text" name="log" id="user_login" aria-describedby="login_error" class="input" value="" size="20" autocapitalize="off" autocomplete="username" required="required" />
			</p>

			<div class="user-pass-wrap">
				<label for="user_pass">Mật khẩu</label>
				<div class="wp-pwd">
					<input type="password" name="pwd" id="user_pass" aria-describedby="login_error" class="input password-input" value="" size="20" autocomplete="current-password" spellcheck="false" required="required" />
					<button type="button" class="button button-secondary wp-hide-pw hide-if-no-js" data-toggle="0" aria-label="Hiện mật khẩu">
						<span class="dashicons dashicons-visibility" aria-hidden="true"></span>
					</button>
				</div>
			</div>
						<p class="forgetmenot"><input name="rememberme" type="checkbox" id="rememberme" value="forever"  /> <label for="rememberme">Tự động đăng nhập</label></p>
			<p class="submit">
				<input type="submit" name="wp-submit" id="wp-submit" class="button button-primary button-large" value="Đăng nhập" />
									<input type="hidden" name="redirect_to" value="https://duhocsmartway.vn/wp-admin/" />
									<input type="hidden" name="testcookie" value="1" />
			</p>
		</form>

					<p id="nav">
				<a class="wp-login-lost-password" href="https://duhocsmartway.vn/wp-login.php?action=lostpassword">Bạn quên mật khẩu?</a>			</p>
			<script type="text/javascript">
/* <![CDATA[ */
function wp_attempt_focus() {setTimeout( function() {try {d = document.getElementById( "user_login" );d.focus(); d.select();} catch( er ) {}}, 200);}
wp_attempt_focus();
if ( typeof wpOnload === 'function' ) { wpOnload() }
/* ]]> */
</script>
		<p id="backtoblog">
			<a href="https://duhocsmartway.vn/">&larr; Quay lại Du Học Smart Way</a>		</p>
			</div>
				<div class="language-switcher">
				<form id="language-switcher" method="get">

					<label for="language-switcher-locales">
						<span class="dashicons dashicons-translation" aria-hidden="true"></span>
						<span class="screen-reader-text">
							Ngôn ngữ						</span>
					</label>

					<select name="wp_lang" id="language-switcher-locales"><option value="en_US" lang="en" data-installed="1">English (United States)</option>
<option value="vi" lang="vi" selected='selected' data-installed="1">Tiếng Việt</option></select>
					
					
					
						<input type="submit" class="button" value="Thay đổi">

					</form>
				</div>
			
	<script type="text/javascript" src="https://duhocsmartway.vn/wp-includes/js/clipboard.min.js?ver=2.0.11" id="clipboard-js"></script>
<script type="text/javascript" src="https://duhocsmartway.vn/wp-includes/js/jquery/jquery.min.js?ver=3.7.1" id="jquery-core-js"></script>
<script type="text/javascript" src="https://duhocsmartway.vn/wp-includes/js/jquery/jquery-migrate.min.js?ver=3.4.1" id="jquery-migrate-js"></script>
<script type="text/javascript" id="zxcvbn-async-js-extra">
/* <![CDATA[ */
var _zxcvbnSettings = {"src":"https:\/\/duhocsmartway.vn\/wp-includes\/js\/zxcvbn.min.js"};
/* ]]> */
</script>
<script type="text/javascript" src="https://duhocsmartway.vn/wp-includes/js/zxcvbn-async.min.js?ver=1.0" id="zxcvbn-async-js"></script>
<script type="text/javascript" src="https://duhocsmartway.vn/wp-includes/js/dist/hooks.min.js?ver=4d63a3d491d11ffd8ac6" id="wp-hooks-js"></script>
<script type="text/javascript" src="https://duhocsmartway.vn/wp-includes/js/dist/i18n.min.js?ver=5e580eb46a90c2b997e6" id="wp-i18n-js"></script>
<script type="text/javascript" id="wp-i18n-js-after">
/* <![CDATA[ */
wp.i18n.setLocaleData( { 'text direction\u0004ltr': [ 'ltr' ] } );
/* ]]> */
</script>
<script type="text/javascript" id="password-strength-meter-js-extra">
/* <![CDATA[ */
var pwsL10n = {"unknown":"M\u1eadt kh\u1ea9u m\u1ea1nh kh\u00f4ng x\u00e1c \u0111\u1ecbnh","short":"R\u1ea5t y\u1ebfu","bad":"Y\u1ebfu","good":"Trung b\u00ecnh","strong":"M\u1ea1nh","mismatch":"M\u1eadt kh\u1ea9u kh\u00f4ng kh\u1edbp"};
/* ]]> */
</script>
<script type="text/javascript" id="password-strength-meter-js-translations">
/* <![CDATA[ */
( function( domain, translations ) {
	var localeData = translations.locale_data[ domain ] || translations.locale_data.messages;
	localeData[""].domain = domain;
	wp.i18n.setLocaleData( localeData, domain );
} )( "default", {"translation-revision-date":"2024-12-31 09:41:22+0000","generator":"GlotPress\/4.0.1","domain":"messages","locale_data":{"messages":{"":{"domain":"messages","plural-forms":"nplurals=1; plural=0;","lang":"vi_VN"},"%1$s is deprecated since version %2$s! Use %3$s instead. Please consider writing more inclusive code.":["%1$s \u0111\u00e3 ng\u1eebng ho\u1ea1t \u0111\u1ed9ng t\u1eeb phi\u00ean b\u1ea3n %2$s! S\u1eed d\u1ee5ng thay th\u1ebf b\u1eb1ng %3$s."]}},"comment":{"reference":"wp-admin\/js\/password-strength-meter.js"}} );
/* ]]> */
</script>
<script type="text/javascript" src="https://duhocsmartway.vn/wp-admin/js/password-strength-meter.min.js?ver=6.7.1" id="password-strength-meter-js"></script>
<script type="text/javascript" src="https://duhocsmartway.vn/wp-includes/js/underscore.min.js?ver=1.13.7" id="underscore-js"></script>
<script type="text/javascript" id="wp-util-js-extra">
/* <![CDATA[ */
var _wpUtilSettings = {"ajax":{"url":"\/wp-admin\/admin-ajax.php"}};
/* ]]> */
</script>
<script type="text/javascript" src="https://duhocsmartway.vn/wp-includes/js/wp-util.min.js?ver=6.7.1" id="wp-util-js"></script>
<script type="text/javascript" src="https://duhocsmartway.vn/wp-includes/js/dist/dom-ready.min.js?ver=f77871ff7694fffea381" id="wp-dom-ready-js"></script>
<script type="text/javascript" id="wp-a11y-js-translations">
/* <![CDATA[ */
( function( domain, translations ) {
	var localeData = translations.locale_data[ domain ] || translations.locale_data.messages;
	localeData[""].domain = domain;
	wp.i18n.setLocaleData( localeData, domain );
} )( "default", {"translation-revision-date":"2025-01-11 03:24:08+0000","generator":"GlotPress\/4.0.1","domain":"messages","locale_data":{"messages":{"":{"domain":"messages","plural-forms":"nplurals=1; plural=0;","lang":"vi_VN"},"Notifications":["Th\u00f4ng b\u00e1o"]}},"comment":{"reference":"wp-includes\/js\/dist\/a11y.js"}} );
/* ]]> */
</script>
<script type="text/javascript" src="https://duhocsmartway.vn/wp-includes/js/dist/a11y.min.js?ver=3156534cc54473497e14" id="wp-a11y-js"></script>
<script type="text/javascript" id="user-profile-js-extra">
/* <![CDATA[ */
var userProfileL10n = {"user_id":"0","nonce":"7e8964828e"};
/* ]]> */
</script>
<script type="text/javascript" id="user-profile-js-translations">
/* <![CDATA[ */
( function( domain, translations ) {
	var localeData = translations.locale_data[ domain ] || translations.locale_data.messages;
	localeData[""].domain = domain;
	wp.i18n.setLocaleData( localeData, domain );
} )( "default", {"translation-revision-date":"2024-12-31 09:41:22+0000","generator":"GlotPress\/4.0.1","domain":"messages","locale_data":{"messages":{"":{"domain":"messages","plural-forms":"nplurals=1; plural=0;","lang":"vi_VN"},"Application password has been copied to your clipboard.":["M\u1eadt kh\u1ea9u \u1ee9ng d\u1ee5ng \u0111\u00e3 \u0111\u01b0\u1ee3c sao ch\u00e9p v\u00e0o b\u1ea3ng t\u1ea1m c\u1ee7a b\u1ea1n."],"Your new password has not been saved.":["M\u1eadt kh\u1ea9u m\u1edbi c\u1ee7a b\u1ea1n ch\u01b0a \u0111\u01b0\u1ee3c l\u01b0u."],"Hide":["\u1ea8n \u0111i"],"Confirm use of weak password":["Ch\u1ea5p nh\u1eadn s\u1eed d\u1ee5ng m\u1eadt kh\u1ea9u y\u1ebfu."],"Hide password":["\u1ea8n m\u1eadt kh\u1ea9u"],"Show password":["Hi\u1ec7n m\u1eadt kh\u1ea9u"],"Show":["Hi\u1ec7n"],"The changes you made will be lost if you navigate away from this page.":["C\u00e1c thay \u0111\u1ed5i b\u1ea1n v\u1eeba th\u1ef1c hi\u1ec7n s\u1ebd b\u1ecb m\u1ea5t n\u1ebfu b\u1ea1n \u0111i kh\u1ecfi trang n\u00e0y khi ch\u01b0a l\u01b0u b\u00e0i."]}},"comment":{"reference":"wp-admin\/js\/user-profile.js"}} );
/* ]]> */
</script>
<script type="text/javascript" src="https://duhocsmartway.vn/wp-admin/js/user-profile.min.js?ver=6.7.1" id="user-profile-js"></script>
	</body>
	</html>
	